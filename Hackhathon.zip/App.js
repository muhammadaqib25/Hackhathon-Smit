import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Login , About, Signup, Request, Map, Check, Checkresult } from './src/screens';


const Stack = createNativeStackNavigator();

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }} >
        <Stack.Screen name="About" component={About} />
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="Signup" component={Signup} />
        <Stack.Screen name="Request" component={Request} />
        <Stack.Screen name="Map" component={Map} />
        <Stack.Screen name="Check" component={Check} />
        <Stack.Screen name="Application" component={Checkresult} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;
