import {initializeApp} from "firebase/app";
import {getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged, signOut} from "firebase/auth";
import {getFirestore, doc , collection,  addDoc, setDoc, updateDoc, getDoc, getDocs, onSnapshot, orderBy, query, where, increment} from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBtMQ2shfV_h6gtNbcJtE1KASyYHNxdb3U",
  authDomain: "hackhaton-531c6.firebaseapp.com",
  databaseURL: "https://hackhaton-531c6-default-rtdb.firebaseio.com",
  projectId: "hackhaton-531c6",
  storageBucket: "hackhaton-531c6.appspot.com",
  messagingSenderId: "453548256359",
  appId: "1:453548256359:web:021ad6895379afdbda38c2"
}

initializeApp(firebaseConfig);
const auth = getAuth();
const db = getFirestore();

export {
  auth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  onAuthStateChanged,
  signOut,
  db,
  collection,
  doc,                         
  addDoc,
  setDoc,
  updateDoc,
  getDoc,
  getDocs,
  onSnapshot,
  orderBy,
  query,
  where,
  increment
};