import { StatusBar } from 'expo-status-bar';
import { Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

export default function About({navigation}) {
    return (
        <View style={styles.container}>
            <View style={styles.Image}>
                <Image source={require('../../assets/logo.png')} style={{ width: 240, height: 150 }} />
            </View>
            <TouchableOpacity style={styles.Login}
                onPress={() => navigation.navigate('Login')}
            >
                <Text style={{ fontSize: 20, color: 'black' }} >Login</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.Signup}
                onPress={() => navigation.navigate('Signup')}
            >
                <Text style={{ fontSize: 20, color: 'black' }}>Signup</Text>
            </TouchableOpacity>
            <StatusBar style="auto" />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'flex-end',
    },
    Image: {
        flex: 0.5
    },
    Login: {
        flex: 0.1,
        width: '100%',
        backgroundColor: '#89C343',
        justifyContent: 'center',
        alignItems: 'center'
    },
    Signup: {
        flex: 0.1,
        width: '100%',
        backgroundColor: '#0A73B7',
        justifyContent: 'center',
        alignItems: 'center'
    }
});