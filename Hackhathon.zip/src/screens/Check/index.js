import { StatusBar } from 'expo-status-bar';
import { Image, StyleSheet, Text, TextInput, TouchableOpacity, View, ScrollView, } from 'react-native';



export default function Check({ navigation }) {
    return (
        <View style={styles.container}>

            <Image source={require('../../assets/Saylanilogo.png')} style={{ width: "80%", height: 150, resizeMode: "contain" }} />
            <View style={styles.Image}>
                <Image source={require('../../assets/logo.png')} style={{ width: 240, height: 150 }} />
            </View>
            <TouchableOpacity style={styles.Submit}
                onPress={() => navigation.navigate('Map')}
            >
                <Text style={{ fontSize: 20, color: '#000' }}>New Application</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.Submit}
                onPress={() => navigation.navigate('Checkresult')}
            >
                <Text style={{ fontSize: 20, color: '#000' }}>Check Application Submission</Text>
            </TouchableOpacity>
            <StatusBar style="auto" />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center'
    },
    Image: {
        flex: 0.7
    },
    Submit: {
        padding: 10,
        width: "90%",
        marginTop: 30,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#89C343',
        color: "#0A73B7",
        borderRadius: 30,
    },
})