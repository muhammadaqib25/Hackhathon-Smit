import React, { useState, useEffect } from 'react';
import MapView from 'react-native-maps';
import { StyleSheet, Text, Platform, View, Dimensions, TouchableOpacity } from 'react-native';
import * as Location from 'expo-location';

export default function User_Location({navigation}) {
    const [location, setLocation] = useState(null);
    const [errorMsg, setErrorMsg] = useState(null);

    useEffect(() => {
        (async () => {
            let { status } = await Location.requestForegroundPermissionsAsync();
            if (status !== 'granted') {
                setErrorMsg('Permission to access location was denied');
                return;
            }

            let location = await Location.getCurrentPositionAsync({});
            setLocation(location);
        })();
    }, []);

    let text = 'Waiting..';
    if (errorMsg) {
        text = errorMsg;
    } else if (location) {
        text = JSON.stringify(location);
    }

    return (
        <View style={styles.container}>
            <View style={styles.container}>
                <MapView style={styles.map}
                    initialRegion={{
                        latitude: location && location.coords.latitude,
                        longitude: location && location.coords.longitude,
                        latitudeDelta: 0.0000000,
                        longitudeDelta: 0.0000000
                    }}
                >
                    {location &&
                        <MapView.Marker
                            style={{ height: 2, width: 2 }}
                            image={require('../../assets/marker.png')}
                            title={"You Are Here"}
                            coordinate={{
                                latitude: location.coords.latitude,
                                longitude: location.coords.longitude
                            }}
                        />}
                    <MapView.Marker
                        coordinate={{
                            latitude: 24.9200172,
                            longitude: 67.0612345
                        }}
                        title={"Aliabad"}
                        description={"Saylani Welfare Roti Bank"}
                        coordinate={{
                            latitude: 24.9200172,
                            longitude: 67.0612345
                        }}
                    />
                    <MapView.Marker
                        coordinate={{
                            latitude: 24.9200172,
                            longitude: 67.0612345
                        }}
                        title={"Numaish Chowrange"}
                        description={"Saylani Welfare Roti Bank"}
                        coordinate={{
                            latitude: 24.8732834,
                            longitude: 67.0337457
                        }}
                    />
                    <MapView.Marker
                        coordinate={{
                            latitude: 24.9200172,
                            longitude: 67.0612345
                        }}
                        title={"Saylani house phase 2"}
                        description={"Saylani Welfare Roti Bank"}
                        coordinate={{
                            latitude: 24.8278999,
                            longitude: 67.0688257
                        }}
                    />
                    <MapView.Marker
                        coordinate={{
                            latitude: 24.9200172,
                            longitude: 67.0612345
                        }}
                        title={"Touheed commercial"}
                        description={"Saylani Welfare Roti Bank"}
                        coordinate={{
                            latitude: 24.8073692,
                            longitude: 67.0357446
                        }}
                    />
                    <MapView.Marker
                        coordinate={{
                            latitude: 24.9200172,
                            longitude: 67.0612345
                        }}
                        title={"Sehar Commercial"}
                        description={"Saylani Welfare Roti Bank"}
                        coordinate={{
                            latitude: 24.8138924,
                            longitude: 67.0677652
                        }}
                    />
                    <MapView.Marker
                        coordinate={{
                            latitude: 24.9200172,
                            longitude: 67.0612345
                        }}
                        title={"Jinnah avenue"}
                        description={"Saylani Welfare Roti Bank"}
                        coordinate={{
                            latitude: 24.8949528,
                            longitude: 67.1767206
                        }}
                    />
                    <MapView.Marker
                        coordinate={{
                            latitude: 24.9200172,
                            longitude: 67.0612345
                        }}
                        title={"Johar Chowrangi"}
                        description={"Saylani Welfare Roti Bank"}
                        coordinate={{
                            latitude: 24.9132328,
                            longitude: 67.1246195
                        }}
                    />
                    <MapView.Marker
                        coordinate={{
                            latitude: 24.9200172,
                            longitude: 67.0612345
                        }}
                        title={"Johar chowrangi 2"}
                        description={"Saylani Welfare Roti Bank"}
                        coordinate={{
                            latitude: 24.9100704,
                            longitude: 67.1208811
                        }}
                    />
                    <MapView.Marker
                        coordinate={{
                            latitude: 24.9200172,
                            longitude: 67.0612345
                        }}
                        title={"Hill park"}
                        description={"Saylani Welfare Roti Bank"}
                        coordinate={{
                            latitude: 24.8673515,
                            longitude: 67.0724497
                        }}
                    />
                </MapView>
            </View>
            <Text style={{display: "none"  }}>{text}</Text>
            <TouchableOpacity
                style={styles.button}
                onPress={() => navigation.navigate('Request')}
            >
                <Text>Next</Text>
            </TouchableOpacity>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    button: {
        alignItems: "center",
        backgroundColor: '#89C343',
        color :  '#0A73B7' , 
        padding: 10,
        width: "90%",
        position : "absolute",
        bottom : 50,
        borderRadius: 30
    },
    map: {
        width: Dimensions.get('window').width,
        height: Dimensions.get('window').height,
    },
});