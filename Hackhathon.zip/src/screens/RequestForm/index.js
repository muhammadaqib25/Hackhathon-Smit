import { StatusBar } from 'expo-status-bar';
import { Image, StyleSheet, Text, TextInput, TouchableOpacity, View, ScrollView, Button, Platform } from 'react-native';
import React, { useState, useEffect } from 'react';
import {
    auth,
    onAuthStateChanged,
    db,
    collection,
    doc,
    setDoc
} from '../../config/firebase';

export default function Request({ navigation }) {
    const [uid, setUid] = useState(null);
    const [name, setName] = useState('')
    const [fname, setFname] = useState('')
    const [cnic, setCnic] = useState('')
    const [date, setDate] = useState('')
    const [member, setMember] = useState('')
    const [income, setIncome] = useState('')

    useEffect(() => {
        onAuthStateChanged(auth, (user) => {
            setUid(user.uid)
        })
    })

    const application = {
        name: name,
        fatherName: fname,
        cnic: cnic,
        dob: date,
        members: member,
        income: income,
        uid: uid
    }

    const submit = async () => {
        const applicationsCol = collection(db, "applications");
        const applicationDoc = doc(applicationsCol, uid);
        await setDoc(applicationDoc, application);
        alert("Application submitted!");
        navigation.navigate('Check');
    }

    return (
        <ScrollView style={styles.scrollView}>
            <View style={styles.container}>

                <View style={styles.Image}>
                    <Image source={require('../../assets/logo.png')} style={{ width: 240, height: 150 }} />
                </View>
                <View >
                    <Text style={styles.Account}>New Request</Text>
                    <TextInput
                        onChangeText={name => setName(name)}
                        value={name}
                        style={styles.input}
                        placeholder="Enter Your Name"
                    />
                    <TextInput
                        onChangeText={fname => setFname(fname)}
                        value={fname}
                        style={styles.input}
                        placeholder="Enter Your FatherName"
                    />
                    <TextInput
                        onChangeText={cnic => setCnic(cnic)}
                        value={cnic}
                        keyboardType="numeric"
                        style={styles.input}
                        placeholder="Enter Your CNIC Number"
                    />
                    <TextInput
                        onChangeText={date => setDate(date)}
                        value={date}
                        keyboardType="numeric"
                        style={styles.input}
                        placeholder="Enter Your Date Of Birth Ex:DD:MM:YY"
                    />
                    <TextInput
                        onChangeText={member => setMember(member)}
                        value={member}
                        keyboardType="numeric"
                        style={styles.input}
                        placeholder="Enter Your Number Of Family Member"
                    />
                    <TextInput
                        onChangeText={income => setIncome(income)}
                        value={income}
                        keyboardType="numeric"
                        style={styles.input}
                        placeholder="Enter Your Monthly Income"
                    />
                </View>
                <TouchableOpacity style={styles.Submit}
                    onPress={() => submit()}
                >
                    <Text style={{ fontSize: 20, color: '#000' }}>Submit</Text>
                </TouchableOpacity>
                <StatusBar style="auto" />
            </View>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center'
    },
    Image: {
        marginTop: 40,
        flex: 0.5
    },
    scrollView: {
        backgroundColor: '#fff',
    },
    input: {
        backgroundColor: 'lightgrey',
        padding: 8,
        width: 300,
        marginVertical: 9,
        borderRadius: 10
    },
    Account: {
        fontSize: 20,
        textAlign: 'center',
        color: '#0A73B7',
        fontWeight: 'bold'
    },
    Submit: {
        padding: 10,
        width: 120,
        marginTop: 30,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#89C343',
        borderRadius: 10,
    },
})