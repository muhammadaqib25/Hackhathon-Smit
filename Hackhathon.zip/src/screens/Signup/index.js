import { createUserWithEmailAndPassword } from '@firebase/auth';
import { collection, addDoc ,setDoc } from "firebase/firestore"; 
import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { Image, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { auth , db ,doc } from '../../config/firebase';



export default function Signup({ navigation }) {
    const [name, setName] = useState('')
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')

    const Register = () => {
        createUserWithEmailAndPassword(auth, email, password)
            .then(async (userCredential) => {
                alert("Authenticated");
                const user = {
                    name: name,
                    email: email,
                    uid: userCredential.user.uid
                }
                const usersCol = collection(db, "users");
                const userDoc = doc(usersCol, `${userCredential.user.uid}`);
                await setDoc(userDoc, user);
                alert("Registered.");
                navigation.navigate('Login')
                // ...
            })
            .catch((error) => {
                const errorCode = error.code;
                const errorMessage = error.message;
                console.log(errorMessage + email + password)
                alert(errorMessage);
                // ..
            });
    }

    return (
        <View style={styles.container}>
            <View style={styles.Image}>
                <Image source={require('../../assets/logo.png')} style={{ width: 240, height: 150 }} />
            </View>
            <View >
                <Text style={styles.Account}>Create Account</Text>
                <TextInput
                    onChangeText={name => setName(name)}
                    value={name}
                    label="Email"
                    type="email"
                    style={styles.inputName}
                    placeholder="Enter Your Name"
                />
                <TextInput
                    onChangeText={email => setEmail(email)}
                    value={email}
                    label="Email"
                    type="email"
                    style={styles.inputEmail}
                    placeholder="Enter Your Email"
                />
                <TextInput
                    onChangeText={password => setPassword(password)}
                    value={password}
                    label="Password"
                    type="password"
                    style={styles.inputPassword}
                    placeholder="Enter Your Password"
                    secureTextEntry
                />
            </View>
            <TouchableOpacity style={styles.Signup}
                onPress={() => Register()}
            >
                <Text style={{ fontSize: 20, color: '#fff' }}>Signup</Text>
            </TouchableOpacity>
            <StatusBar style="auto" />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    Image: {
        flex: 0.4
    },
    inputName: {
        backgroundColor: 'lightgrey',
        padding: 8,
        width: 300,
        marginVertical: 9,
        borderRadius: 20
    },
    inputEmail: {
        backgroundColor: 'lightgrey',
        padding: 8,
        width: 300,
        marginVertical: 9,
        borderRadius: 20
    },
    inputPassword: {
        backgroundColor: 'lightgrey',
        padding: 8,
        width: 300,
        marginVertical : 9 ,
        borderRadius: 20
    },
    Signup: {
        padding: 10,
        width: '50%',
        marginTop: 30,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#89C343',
        borderRadius: 30,
    },
    Account: {
        fontSize: 20,
        textAlign: 'center',
        color: '#0A73B7',
        fontWeight: 'bold'
    }
});