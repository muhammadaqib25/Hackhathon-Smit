import About from "./About";
import Check from "./Check";
import Checkresult from "./chksubmit";
import Login from "./login"
import Map from "./Map";
import Request from "./RequestForm";
import Signup from "./Signup";

export {
    About,
    Login,
    Signup,
    Request,
    Map,
    Check,
    Checkresult,
}