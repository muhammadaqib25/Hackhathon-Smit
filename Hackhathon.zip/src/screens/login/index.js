import {signInWithEmailAndPassword } from "firebase/auth";
import { StatusBar } from 'expo-status-bar';
import { Image, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { auth } from '../../config/firebase';
import { useState } from "react";

export default function Login({ navigation }) {
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')

    const Signin = () => {
        signInWithEmailAndPassword(auth, email, password)
            .then((userCredential) => {
                // Signed in 
                const user = userCredential.user;
                alert("Login Success");
                navigation.navigate('Check')
                // ...
            })
            .catch((error) => {
                const errorCode = error.code;
                const errorMessage = error.message;
                alert(errorMessage);
            });

    }

    return (
        <View style={styles.container}>
            <View style={styles.Image}>
                <Image source={require('../../assets/logo.png')} style={{ width: 240, height: 150 }} />
            </View>
            <View >
                <Text style={styles.Account}>Login Here</Text>
                <TextInput
                    onChangeText={email => setEmail(email)}
                    value={email}
                    label="Email"
                    type="email"
                    style={styles.inputEmail}
                    placeholder="Enter Your Email"
                />
                <TextInput
                    onChangeText={password => setPassword(password)}
                    value={password}
                    label="Password"
                    type="password"
                    style={styles.inputPassword}
                    placeholder="Enter Your Password"
                    secureTextEntry
                />
            </View>
            <TouchableOpacity style={styles.Login}
                onPress={() => Signin()}
            >
                <Text style={{ fontSize: 20, color: '#fff' }}>Login</Text>
            </TouchableOpacity>
            <StatusBar style="auto" />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    Image: {
        flex: 0.7
    },
    inputEmail: {
        backgroundColor: 'lightgrey',
        padding: 8,
        width: 300,
        marginVertical: 18,
        borderRadius: 10
    },
    inputPassword: {
        backgroundColor: 'lightgrey',
        padding: 8,
        width: 300,
        borderRadius: 10
    },
    Login: {
        padding: 10,
        width: 120,
        marginTop: 30,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#89C343',
        borderRadius: 10,
    },
    Account: {
        fontSize: 20,
        textAlign: 'center',
        color: '#0A73B7',
        fontWeight: 'bold'
    }
});